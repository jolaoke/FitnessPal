<?php
$username="root";
$password="";
$database="fitness_pal";
$conn=mysqli_connect('localhost',$username,$password,$database) or die("Connection could not be established.");
?>