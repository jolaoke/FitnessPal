<footer class="footer">
    <div class="container">
    <p class="text-center"><em>FitnessPal</em> developed by <strong> Mojolaoluwa Oke</strong>, Email: <a href="mailto:jola_oke@outlook.com">jola_oke@outlook.com</a><p>
    </div>
</footer>